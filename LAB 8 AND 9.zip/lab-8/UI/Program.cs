using BL;
using DAL;
using DataAccessLayer;
using Model;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// 1. API Controllers & OpenAPI Services
builder.Services.AddControllers();
builder.Services.AddOpenApi();

// 2. Dependency Injection (Supabase Repository Use Karein)
builder.Services.AddScoped<IProductRepository, SupabaseProductRepo>();
builder.Services.AddScoped<IProductService, ProductService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

// 3. Map OpenAPI and Scalar UI in Development
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// 4. Map API Controller Endpoints
app.MapControllers();

app.MapRazorComponents<UI.Components.App>()
    .AddInteractiveServerRenderMode();

app.Run();