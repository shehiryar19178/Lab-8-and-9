﻿using Microsoft.AspNetCore.Mvc;
using DAL;
using Model;

namespace UI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository _repo;

        public ProductsController(IProductRepository repo)
        {
            _repo = repo;
        }

        // 1. GET: api/products
        [HttpGet]
        public ActionResult<List<Product>> GetAll()
        {
            var products = _repo.GetAll();
            return Ok(products);
        }

        // 2. GET: api/products/{id}
        [HttpGet("{id}")]
        public ActionResult<Product> GetById(int id)
        {
            var product = _repo.GetById(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        // 3. POST: api/products
        [HttpPost]
        public ActionResult Create([FromBody] Product product)
        {
            _repo.Add(product);
            return Ok(product);
        }

        // 4. PUT: api/products/{id}
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Product product)
        {
            var existingProduct = _repo.GetById(id);
            if (existingProduct == null)
            {
                return NotFound();
            }

            _repo.Update(product);
            return NoContent();
        }

        // 5. DELETE: api/products/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existingProduct = _repo.GetById(id);
            if (existingProduct == null)
            {
                return NotFound();
            }

            _repo.Delete(id);
            return NoContent();
        }
    }
}