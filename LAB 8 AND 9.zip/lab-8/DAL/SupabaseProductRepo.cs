﻿using DataAccessLayer;
using Model;
using Npgsql;
using System;
using System.Collections.Generic;

namespace DAL
{
    public class SupabaseProductRepo : IProductRepository
    {
        public List<Product> GetAll()
        {
            var products = new List<Product>();
            const string query = @"SELECT ""Id"", ""Name"", ""Price"", ""Category"" FROM ""Products"" ORDER BY ""Id"";";

            using var con = DBHelper.GetConnection();
            con.Open();
            using var cmd = new NpgsqlCommand(query, con);
            using var dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                products.Add(MapProduct(dr));
            }

            return products;
        }

        public Product? GetById(int id)
        {
            Product? product = null;
            const string query = @"SELECT ""Id"", ""Name"", ""Price"", ""Category"" FROM ""Products"" WHERE ""Id"" = @Id;";

            using var con = DBHelper.GetConnection();
            con.Open();
            using var cmd = new NpgsqlCommand(query, con);
            cmd.Parameters.AddWithValue("Id", id);

            using var dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                product = MapProduct(dr);
            }

            return product;
        }

        public void Add(Product product)
        {
            const string query = @"INSERT INTO ""Products"" (""Name"", ""Price"", ""Category"") VALUES (@Name, @Price, @Category);";

            using var con = DBHelper.GetConnection();
            con.Open();
            using var cmd = new NpgsqlCommand(query, con);

            cmd.Parameters.AddWithValue("Name", product.Name ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Price", product.Price);
            cmd.Parameters.AddWithValue("Category", product.Category ?? (object)DBNull.Value);
            cmd.ExecuteNonQuery();
        }

        public void Update(Product product)
        {
            const string query = @"UPDATE ""Products"" SET ""Name"" = @Name, ""Price"" = @Price, ""Category"" = @Category WHERE ""Id"" = @Id;";

            using var con = DBHelper.GetConnection();
            con.Open();
            using var cmd = new NpgsqlCommand(query, con);

            cmd.Parameters.AddWithValue("Id", product.P_Id);
            cmd.Parameters.AddWithValue("Name", product.Name ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Price", product.Price);
            cmd.Parameters.AddWithValue("Category", product.Category ?? (object)DBNull.Value);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            const string query = @"DELETE FROM ""Products"" WHERE ""Id"" = @Id;";

            using var con = DBHelper.GetConnection();
            con.Open();
            using var cmd = new NpgsqlCommand(query, con);

            cmd.Parameters.AddWithValue("Id", id);
            cmd.ExecuteNonQuery();
        }

        private static Product MapProduct(NpgsqlDataReader dr)
        {
            return new Product
            {
                P_Id = dr.GetInt32(dr.GetOrdinal("Id")),
                Name = dr.IsDBNull(dr.GetOrdinal("Name")) ? string.Empty : dr.GetString(dr.GetOrdinal("Name")),
                Price = dr.GetDecimal(dr.GetOrdinal("Price")),
                Category = dr.IsDBNull(dr.GetOrdinal("Category")) ? string.Empty : dr.GetString(dr.GetOrdinal("Category"))
            };
        }
    }
}