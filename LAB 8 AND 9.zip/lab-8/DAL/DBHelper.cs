﻿using System;
using Npgsql;

namespace DataAccessLayer
{
    public class DBHelper
    {
        public static NpgsqlConnection GetConnection()
        {
            var connString = "Host=aws-0-ap-southeast-1.pooler.supabase.com;Port=5432;Database=postgres;Username=postgres.ibpkmnjuqfpkjbczrska;Password=SHEHRYAR@115;";
            return new NpgsqlConnection(connString);
        }
    }
}
