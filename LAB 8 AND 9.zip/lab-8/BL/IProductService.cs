﻿using Model;

namespace BL;

public interface IProductService
{
    List<Product> GetAll();
    Product? GetById(int id);
    void Add(Product product);
    void Update(Product product);
    void Delete(int id);
    List<Product> SearchByName(string name);
    List<Product> FilterByCategory(string category);
    List<Product> FilterByMinPrice(decimal minPrice);
    List<Product> SortByPid(bool ascending);
    List<Product> SortByName(bool ascending);
    List<Product> SortByPrice(bool ascending);
    Product? GetMostExpensiveProduct();
    Product? GetCheapestProduct();
    int GetTotalProductsCount();
}