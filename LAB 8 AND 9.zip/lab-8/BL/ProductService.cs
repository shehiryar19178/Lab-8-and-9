﻿using DAL;
using Model;

namespace BL;

public class ProductService : IProductService
{
    private readonly IProductRepository _repo;

    public ProductService(IProductRepository repo) => _repo = repo;

    public List<Product> GetAll() => _repo.GetAll();

    public Product? GetById(int id) => _repo.GetById(id);

    public void Add(Product product)
    {
        Validate(product);
        _repo.Add(product);
    }

    public void Update(Product product)
    {
        if (product.P_Id <= 0) throw new ArgumentException("Invalid product id.");
        Validate(product);
        _repo.Update(product);
    }

    public void Delete(int id)
    {
        if (id <= 0) throw new ArgumentException("Invalid product id.");
        _repo.Delete(id);
    }

    private static void Validate(Product p)
    {
        if (string.IsNullOrWhiteSpace(p.Name))
            throw new ArgumentException("Product name is required.");
        if (p.Price <= 0)
            throw new ArgumentException("Price must be greater than zero.");
        if (string.IsNullOrWhiteSpace(p.Category))
            throw new ArgumentException("Category is required.");
    }

    // --- Implementation for Lab Tasks 5-14 ---
    public List<Product> SearchByName(string name) =>
        _repo.GetAll().Where(p => p.Name.Contains(name, StringComparison.OrdinalIgnoreCase)).ToList();

    public List<Product> FilterByCategory(string category) =>
        _repo.GetAll().Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();

    public List<Product> FilterByMinPrice(decimal minPrice) =>
        _repo.GetAll().Where(p => p.Price >= minPrice).ToList();

    public List<Product> SortByPid(bool ascending) =>
        ascending ? _repo.GetAll().OrderBy(p => p.P_Id).ToList() : _repo.GetAll().OrderByDescending(p => p.P_Id).ToList();

    public List<Product> SortByName(bool ascending) =>
        ascending ? _repo.GetAll().OrderBy(p => p.Name).ToList() : _repo.GetAll().OrderByDescending(p => p.Name).ToList();

    public List<Product> SortByPrice(bool ascending) =>
        ascending ? _repo.GetAll().OrderBy(p => p.Price).ToList() : _repo.GetAll().OrderByDescending(p => p.Price).ToList();

    public Product? GetMostExpensiveProduct() =>
        _repo.GetAll().OrderByDescending(p => p.Price).FirstOrDefault();

    public Product? GetCheapestProduct() =>
        _repo.GetAll().OrderBy(p => p.Price).FirstOrDefault();

    public int GetTotalProductsCount() =>
        _repo.GetAll().Count;
}